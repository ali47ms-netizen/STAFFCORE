const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('node:path');
function createWindow(){
 const win = new BrowserWindow({
  width:1440,height:940,minWidth:900,minHeight:650,
  title:'STAFFCORE — مدیریت استاف',
  backgroundColor:'#0d0d16',
  webPreferences:{contextIsolation:true,nodeIntegration:false,sandbox:true}
 });
 win.loadFile(path.join(__dirname,'index.html'));
}
app.whenReady().then(()=>{Menu.setApplicationMenu(null);createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow()})});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
